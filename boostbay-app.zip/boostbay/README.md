# BOOSTBAY – tuning alkatrész webshop (API + WPF)

## Indítás
1. Adatbázis: `docker compose up -d` (mysql:8.4, adatbázis: `boostbay`, user: `boost` / `boostjelszo`)
2. API: `cd Api && dotnet run` → http://localhost:5080/swagger (induláskor létrehozza a táblákat és feltölti mintaadatokkal)
3. WPF: `cd Wpf && dotnet run` (Windows, .NET 8)

Migrációhoz (opcionális): `dotnet ef migrations add Init` majd `dotnet ef database update`, és a Program.cs-ben az `EnsureCreated` helyett `Migrate()`.

## API (REST, controller alapú, EF Core Code-First)
| Endpoint | CRUD | Saját függvények |
|---|---|---|
| `/api/products` | GET, GET {id}, POST, PUT {id}, DELETE {id} | `GET search?q=&maxPrice=`, `GET low-stock?threshold=`, `POST {id}/restock?amount=` |
| `/api/categories` | GET, GET {id}, POST, PUT {id}, DELETE {id} | `GET {id}/products`, `GET stats` |
| `/api/orders` | GET, GET {id}, POST (készletellenőrzéssel), PUT {id}, DELETE {id} | `PUT {id}/status?value=`, `GET revenue` |

## WPF (MVVM)
Nézetek: Alkatrészek, Kategóriák, Rendelések (ContentControl + DataTemplate navigáció, Binding, ICommand, ObservableCollection).
