using Microsoft.EntityFrameworkCore;
namespace BoostBay.Api;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<Product>().HasOne(p => p.Category).WithMany(c => c.Products)
            .HasForeignKey(p => p.CategoryId).OnDelete(DeleteBehavior.Restrict);
        mb.Entity<Order>().HasMany(o => o.Items).WithOne().HasForeignKey(i => i.OrderId).OnDelete(DeleteBehavior.Cascade);
        mb.Entity<OrderItem>().HasOne(i => i.Product).WithMany()
            .HasForeignKey(i => i.ProductId).OnDelete(DeleteBehavior.Restrict);

        mb.Entity<Category>().HasData(
            new Category { Id = 1, Name = "Turbó", Description = "Turbófeltöltők és kiegészítők" },
            new Category { Id = 2, Name = "Kompresszor", Description = "Mechanikus feltöltők" },
            new Category { Id = 3, Name = "Motor belső", Description = "Dugattyú, hajtókar, csapágy" },
            new Category { Id = 4, Name = "Gyújtás", Description = "Gyertyák, tekercsek" },
            new Category { Id = 5, Name = "Kipufogó", Description = "Leömlő, straight pipe, cat-back" });
        mb.Entity<Product>().HasData(
            new Product { Id = 1, Name = "Garrett G30-770 turbófeltöltő", SpecValue = "+140 LE", Price = 489000, Stock = 5, CategoryId = 1 },
            new Product { Id = 2, Name = "Eaton kompresszor készlet V8-hoz", SpecValue = "+110 LE", Price = 1290000, Stock = 2, CategoryId = 2 },
            new Product { Id = 3, Name = "Kovácsolt dugattyúkészlet 4 db", SpecValue = "11,5 bar", Price = 238000, Stock = 6, CategoryId = 3 },
            new Product { Id = 4, Name = "Versenycsapágy szett", SpecValue = "0,025 mm", Price = 68000, Stock = 12, CategoryId = 3 },
            new Product { Id = 5, Name = "Iridium versenygyertya 4 db", SpecValue = "8–9 bar", Price = 36000, Stock = 40, CategoryId = 4 },
            new Product { Id = 6, Name = "Rozsdamentes tuning leömlő 4-2-1", SpecValue = "+12 LE", Price = 179000, Stock = 4, CategoryId = 5 },
            new Product { Id = 7, Name = "Straight pipe 76 mm", SpecValue = "76 mm", Price = 94000, Stock = 9, CategoryId = 5 });
    }
}
