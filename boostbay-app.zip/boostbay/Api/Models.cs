using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BoostBay.Api;

public class Category
{
    [Key] public int Id { get; set; }
    [Required, MaxLength(60)] public string Name { get; set; } = "";
    [MaxLength(200)] public string? Description { get; set; }
    public List<Product> Products { get; set; } = new();
}

public class Product
{
    [Key] public int Id { get; set; }
    [Required, MaxLength(120)] public string Name { get; set; } = "";
    [MaxLength(60)] public string? SpecValue { get; set; }
    [Column(TypeName = "decimal(12,2)")] public decimal Price { get; set; }
    public int Stock { get; set; }
    [ForeignKey("Category")] public int CategoryId { get; set; }
    public Category? Category { get; set; }
}

public class Order
{
    [Key] public int Id { get; set; }
    [Required, MaxLength(80)] public string CustomerName { get; set; } = "";
    [MaxLength(120)] public string? Email { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    [MaxLength(20)] public string Status { get; set; } = "Új";
    public List<OrderItem> Items { get; set; } = new();
}

public class OrderItem
{
    [Key] public int Id { get; set; }
    public int OrderId { get; set; }
    public int ProductId { get; set; }
    public int Quantity { get; set; }
    [Column(TypeName = "decimal(12,2)")] public decimal UnitPrice { get; set; }
    public Product? Product { get; set; }
}

public record NewOrderLine(int ProductId, int Quantity);
public record NewOrderDto(string CustomerName, string? Email, List<NewOrderLine> Items);
