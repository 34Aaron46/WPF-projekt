using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace BoostBay.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CategoriesController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<Category>>> GetAll() =>
        await db.Categories.Select(c => new Category { Id = c.Id, Name = c.Name, Description = c.Description }).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Category>> Get(int id)
    {
        var c = await db.Categories.FindAsync(id);
        return c is null ? NotFound() : c;
    }

    [HttpPost]
    public async Task<ActionResult<Category>> Create(Category c)
    {
        c.Id = 0; c.Products = new();
        db.Categories.Add(c);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = c.Id }, c);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, Category c)
    {
        if (id != c.Id) return BadRequest("Az id nem egyezik.");
        var db_c = await db.Categories.FindAsync(id);
        if (db_c is null) return NotFound();
        db_c.Name = c.Name; db_c.Description = c.Description;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var c = await db.Categories.FindAsync(id);
        if (c is null) return NotFound();
        db.Categories.Remove(c);
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateException) { return Conflict("A kategóriában még vannak termékek."); }
        return NoContent();
    }

    // Saját függvény 1: egymásba ágyazott erőforrás
    [HttpGet("{id:int}/products")]
    public async Task<ActionResult<List<Product>>> ProductsOf(int id)
    {
        if (!await db.Categories.AnyAsync(c => c.Id == id)) return NotFound();
        return await db.Products.Where(p => p.CategoryId == id).ToListAsync();
    }

    // Saját függvény 2: kategóriánkénti statisztika
    [HttpGet("stats")]
    public async Task<IActionResult> Stats() =>
        Ok(await db.Categories.Select(c => new
        {
            c.Id, c.Name,
            ProductCount = c.Products.Count,
            StockValue = c.Products.Sum(p => p.Price * p.Stock)
        }).ToListAsync());
}
