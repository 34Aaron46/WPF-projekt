using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace BoostBay.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController(AppDbContext db) : ControllerBase
{
    static readonly string[] Statuses = { "Új", "Feldolgozás alatt", "Kiszállítva", "Törölve" };
    IQueryable<Order> Full => db.Orders.Include(o => o.Items).ThenInclude(i => i.Product);

    [HttpGet]
    public async Task<ActionResult<List<Order>>> GetAll() => await Full.OrderByDescending(o => o.CreatedAt).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Order>> Get(int id)
    {
        var o = await Full.FirstOrDefaultAsync(x => x.Id == id);
        return o is null ? NotFound() : o;
    }

    [HttpPost]
    public async Task<ActionResult<Order>> Create(NewOrderDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.CustomerName) || dto.Items.Count == 0)
            return BadRequest("Név és legalább egy tétel kötelező.");
        await using var tx = await db.Database.BeginTransactionAsync();
        var order = new Order { CustomerName = dto.CustomerName, Email = dto.Email };
        foreach (var line in dto.Items)
        {
            var p = await db.Products.FindAsync(line.ProductId);
            if (p is null) return BadRequest($"Nincs ilyen termék: {line.ProductId}");
            if (line.Quantity <= 0 || p.Stock < line.Quantity) return BadRequest($"Nincs elég készlet: {p.Name}");
            p.Stock -= line.Quantity;
            order.Items.Add(new OrderItem { ProductId = p.Id, Quantity = line.Quantity, UnitPrice = p.Price });
        }
        db.Orders.Add(order);
        await db.SaveChangesAsync();
        await tx.CommitAsync();
        return CreatedAtAction(nameof(Get), new { id = order.Id }, await Full.FirstAsync(o => o.Id == order.Id));
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, Order o)
    {
        var cur = await db.Orders.FindAsync(id);
        if (cur is null) return NotFound();
        if (!Statuses.Contains(o.Status)) return BadRequest("Érvénytelen állapot.");
        cur.CustomerName = o.CustomerName; cur.Email = o.Email; cur.Status = o.Status;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var o = await db.Orders.FindAsync(id);
        if (o is null) return NotFound();
        db.Orders.Remove(o);
        await db.SaveChangesAsync();
        return NoContent();
    }

    // Saját függvény 1: állapot módosítása
    [HttpPut("{id:int}/status")]
    public async Task<IActionResult> SetStatus(int id, [FromQuery] string value)
    {
        if (!Statuses.Contains(value)) return BadRequest("Érvénytelen állapot.");
        var o = await db.Orders.FindAsync(id);
        if (o is null) return NotFound();
        o.Status = value;
        await db.SaveChangesAsync();
        return NoContent();
    }

    // Saját függvény 2: bevétel (törölt rendelések nélkül)
    [HttpGet("revenue")]
    public async Task<ActionResult<decimal>> Revenue() =>
        await db.OrderItems.Where(i => db.Orders.Any(o => o.Id == i.OrderId && o.Status != "Törölve"))
            .SumAsync(i => i.UnitPrice * i.Quantity);
}
