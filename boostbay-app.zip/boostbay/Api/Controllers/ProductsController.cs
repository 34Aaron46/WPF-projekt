using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace BoostBay.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<List<Product>>> GetAll() =>
        await db.Products.Include(p => p.Category).OrderBy(p => p.Name).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Product>> Get(int id)
    {
        var p = await db.Products.Include(x => x.Category).FirstOrDefaultAsync(x => x.Id == id);
        return p is null ? NotFound() : p;
    }

    [HttpPost]
    public async Task<ActionResult<Product>> Create(Product p)
    {
        if (!await db.Categories.AnyAsync(c => c.Id == p.CategoryId)) return BadRequest("Nincs ilyen kategória.");
        p.Id = 0; p.Category = null;
        db.Products.Add(p);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = p.Id }, p);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, Product p)
    {
        if (id != p.Id) return BadRequest("Az id nem egyezik.");
        if (!await db.Products.AnyAsync(x => x.Id == id)) return NotFound();
        if (!await db.Categories.AnyAsync(c => c.Id == p.CategoryId)) return BadRequest("Nincs ilyen kategória.");
        p.Category = null;
        db.Entry(p).State = EntityState.Modified;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var p = await db.Products.FindAsync(id);
        if (p is null) return NotFound();
        db.Products.Remove(p);
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateException) { return Conflict("A termék szerepel rendelésben, nem törölhető."); }
        return NoContent();
    }

    // Saját függvény 1: keresés névre és maximum árra
    [HttpGet("search")]
    public async Task<ActionResult<List<Product>>> Search([FromQuery] string? q, [FromQuery] decimal? maxPrice)
    {
        var query = db.Products.Include(p => p.Category).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(p => p.Name.Contains(q));
        if (maxPrice.HasValue) query = query.Where(p => p.Price <= maxPrice);
        return await query.OrderBy(p => p.Price).ToListAsync();
    }

    // Saját függvény 2: alacsony készletű termékek
    [HttpGet("low-stock")]
    public async Task<ActionResult<List<Product>>> LowStock([FromQuery] int threshold = 5) =>
        await db.Products.Include(p => p.Category).Where(p => p.Stock <= threshold).OrderBy(p => p.Stock).ToListAsync();

    // Saját függvény 3: készlet feltöltése
    [HttpPost("{id:int}/restock")]
    public async Task<ActionResult<Product>> Restock(int id, [FromQuery] int amount)
    {
        if (amount <= 0) return BadRequest("A mennyiség legyen pozitív.");
        var p = await db.Products.FindAsync(id);
        if (p is null) return NotFound();
        p.Stock += amount;
        await db.SaveChangesAsync();
        return p;
    }
}
