namespace BoostBay.Wpf;
public partial class OrdersView : System.Windows.Controls.UserControl { public OrdersView() { InitializeComponent(); } }
