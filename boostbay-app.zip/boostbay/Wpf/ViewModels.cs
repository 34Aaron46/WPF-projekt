using System.Collections.ObjectModel;
using System.Windows.Input;
namespace BoostBay.Wpf;

public class ProductsVM : BaseVM
{
    public ObservableCollection<ProductDto> Items { get; } = new();
    public ObservableCollection<CategoryDto> Categories { get; } = new();
    ProductDto? sel; string name = "", spec = "", query = ""; decimal price; int stock, catId;
    public ProductDto? Selected { get => sel; set { Set(ref sel, value); if (value != null) { Name = value.Name; Spec = value.SpecValue ?? ""; Price = value.Price; Stock = value.Stock; CatId = value.CategoryId; } } }
    public string Name { get => name; set => Set(ref name, value); }
    public string Spec { get => spec; set => Set(ref spec, value); }
    public decimal Price { get => price; set => Set(ref price, value); }
    public int Stock { get => stock; set => Set(ref stock, value); }
    public int CatId { get => catId; set => Set(ref catId, value); }
    public string Query { get => query; set => Set(ref query, value); }
    public ICommand LoadCmd { get; }
    public ICommand NewCmd { get; }
    public ICommand SaveCmd { get; }
    public ICommand DeleteCmd { get; }
    public ICommand SearchCmd { get; }
    public ICommand LowCmd { get; }
    public ICommand RestockCmd { get; }

    public ProductsVM()
    {
        LoadCmd = C(Load);
        NewCmd = C(async () => { Selected = null; Name = Spec = ""; Price = 0; Stock = 0; await Task.CompletedTask; });
        SaveCmd = C(async () =>
        {
            var dto = new { id = sel?.Id ?? 0, name = Name, specValue = Spec, price = Price, stock = Stock, categoryId = CatId };
            if (sel == null) await Api.Send(HttpMethod.Post, "products", dto); else await Api.Send(HttpMethod.Put, $"products/{sel.Id}", dto);
            await Load(); Status = "Mentve.";
        });
        DeleteCmd = C(async () => { if (sel == null) return; await Api.Send(HttpMethod.Delete, $"products/{sel.Id}"); await Load(); Status = "Törölve."; });
        SearchCmd = C(async () => Fill(await Api.Get<List<ProductDto>>($"products/search?q={Uri.EscapeDataString(Query)}")));
        LowCmd = C(async () => Fill(await Api.Get<List<ProductDto>>("products/low-stock?threshold=5")));
        RestockCmd = C(async () => { if (sel == null) return; await Api.Send(HttpMethod.Post, $"products/{sel.Id}/restock?amount=10"); await Load(); Status = "+10 db feltöltve."; });
    }
    void Fill(List<ProductDto>? l) { Items.Clear(); foreach (var p in l ?? new()) Items.Add(p); Status = $"{Items.Count} termék"; }
    public override async Task Load()
    {
        Categories.Clear(); foreach (var c in await Api.Get<List<CategoryDto>>("categories") ?? new()) Categories.Add(c);
        Fill(await Api.Get<List<ProductDto>>("products"));
    }
}

public class CategoriesVM : BaseVM
{
    public ObservableCollection<CategoryDto> Items { get; } = new();
    public ObservableCollection<ProductDto> Related { get; } = new();
    public ObservableCollection<StatDto> Stats { get; } = new();
    CategoryDto? sel; string name = "", desc = "";
    public CategoryDto? Selected { get => sel; set { Set(ref sel, value); if (value != null) { Name = value.Name; Desc = value.Description ?? ""; _ = ShowProducts(); } } }
    public string Name { get => name; set => Set(ref name, value); }
    public string Desc { get => desc; set => Set(ref desc, value); }
    public ICommand NewCmd { get; }
    public ICommand SaveCmd { get; }
    public ICommand DeleteCmd { get; }
    public ICommand StatsCmd { get; }
    public CategoriesVM()
    {
        NewCmd = C(async () => { Selected = null; Name = Desc = ""; Related.Clear(); await Task.CompletedTask; });
        SaveCmd = C(async () =>
        {
            var dto = new { id = sel?.Id ?? 0, name = Name, description = Desc };
            if (sel == null) await Api.Send(HttpMethod.Post, "categories", dto); else await Api.Send(HttpMethod.Put, $"categories/{sel.Id}", dto);
            await Load(); Status = "Mentve.";
        });
        DeleteCmd = C(async () => { if (sel == null) return; await Api.Send(HttpMethod.Delete, $"categories/{sel.Id}"); await Load(); Status = "Törölve."; });
        StatsCmd = C(async () => { Stats.Clear(); foreach (var s in await Api.Get<List<StatDto>>("categories/stats") ?? new()) Stats.Add(s); });
    }
    async Task ShowProducts()
    {
        try { Related.Clear(); foreach (var p in await Api.Get<List<ProductDto>>($"categories/{sel!.Id}/products") ?? new()) Related.Add(p); }
        catch (Exception e) { Status = "Hiba: " + e.Message; }
    }
    public override async Task Load()
    {
        Items.Clear(); foreach (var c in await Api.Get<List<CategoryDto>>("categories") ?? new()) Items.Add(c);
        Status = $"{Items.Count} kategória";
    }
}

public class OrdersVM : BaseVM
{
    public ObservableCollection<OrderDto> Items { get; } = new();
    public ObservableCollection<ProductDto> Products { get; } = new();
    public ObservableCollection<BasketLine> Basket { get; } = new();
    public string[] Statuses { get; } = { "Új", "Feldolgozás alatt", "Kiszállítva", "Törölve" };
    OrderDto? sel; string cust = "", email = "", newStatus = "Új", revenue = ""; ProductDto? pick; int qty = 1;
    public OrderDto? Selected { get => sel; set { Set(ref sel, value); if (value != null) NewStatus = value.Status; } }
    public string Customer { get => cust; set => Set(ref cust, value); }
    public string Email { get => email; set => Set(ref email, value); }
    public string NewStatus { get => newStatus; set => Set(ref newStatus, value); }
    public string Revenue { get => revenue; set => Set(ref revenue, value); }
    public ProductDto? Pick { get => pick; set => Set(ref pick, value); }
    public int Qty { get => qty; set => Set(ref qty, value); }
    public ICommand AddLineCmd { get; }
    public ICommand PlaceCmd { get; }
    public ICommand StatusCmd { get; }
    public ICommand DeleteCmd { get; }
    public ICommand RevenueCmd { get; }
    public OrdersVM()
    {
        AddLineCmd = C(async () => { if (pick != null && qty > 0) Basket.Add(new BasketLine { Product = pick, Quantity = qty }); await Task.CompletedTask; });
        PlaceCmd = C(async () =>
        {
            await Api.Send(HttpMethod.Post, "orders", new { customerName = Customer, email = Email, items = Basket.Select(b => new { productId = b.Product.Id, quantity = b.Quantity }) });
            Basket.Clear(); Customer = Email = ""; await Load(); Status = "Rendelés leadva.";
        });
        StatusCmd = C(async () => { if (sel == null) return; await Api.Send(HttpMethod.Put, $"orders/{sel.Id}/status?value={Uri.EscapeDataString(NewStatus)}"); await Load(); Status = "Állapot mentve."; });
        DeleteCmd = C(async () => { if (sel == null) return; await Api.Send(HttpMethod.Delete, $"orders/{sel.Id}"); await Load(); Status = "Törölve."; });
        RevenueCmd = C(async () => Revenue = $"Bevétel: {await Api.Get<decimal>("orders/revenue"):N0} Ft");
    }
    public override async Task Load()
    {
        Products.Clear(); foreach (var p in await Api.Get<List<ProductDto>>("products") ?? new()) Products.Add(p);
        Items.Clear(); foreach (var o in await Api.Get<List<OrderDto>>("orders") ?? new()) Items.Add(o);
    }
}

public class MainVM : Obs
{
    public ProductsVM Products { get; } = new();
    public CategoriesVM Categories { get; } = new();
    public OrdersVM Orders { get; } = new();
    BaseVM? current; public BaseVM? Current { get => current; set => Set(ref current, value); }
    public ICommand ShowProducts { get; }
    public ICommand ShowCategories { get; }
    public ICommand ShowOrders { get; }
    public MainVM()
    {
        ShowProducts = new Cmd(() => Go(Products));
        ShowCategories = new Cmd(() => Go(Categories));
        ShowOrders = new Cmd(() => Go(Orders));
        _ = Go(Products);
    }
    async Task Go(BaseVM vm)
    {
        Current = vm;
        try { await vm.Load(); } catch (Exception e) { vm.Status = "Az API nem érhető el: " + e.Message; }
    }
}
