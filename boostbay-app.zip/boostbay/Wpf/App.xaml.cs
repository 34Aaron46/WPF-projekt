namespace BoostBay.Wpf;
public partial class App : System.Windows.Application { }
