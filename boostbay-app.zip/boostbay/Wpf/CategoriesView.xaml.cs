namespace BoostBay.Wpf;
public partial class CategoriesView : System.Windows.Controls.UserControl { public CategoriesView() { InitializeComponent(); } }
