using System.ComponentModel;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Windows.Input;
namespace BoostBay.Wpf;

// ---- Model (DTO-k) ----
public class CategoryDto { public int Id { get; set; } public string Name { get; set; } = ""; public string? Description { get; set; } }
public class ProductDto
{
    public int Id { get; set; } public string Name { get; set; } = ""; public string? SpecValue { get; set; }
    public decimal Price { get; set; } public int Stock { get; set; } public int CategoryId { get; set; }
    public CategoryDto? Category { get; set; }
}
public class OrderItemDto { public int ProductId { get; set; } public int Quantity { get; set; } public decimal UnitPrice { get; set; } public ProductDto? Product { get; set; } }
public class OrderDto
{
    public int Id { get; set; } public string CustomerName { get; set; } = ""; public string? Email { get; set; }
    public DateTime CreatedAt { get; set; } public string Status { get; set; } = "Új"; public List<OrderItemDto> Items { get; set; } = new();
    public decimal Total => Items.Sum(i => i.Quantity * i.UnitPrice);
    public string Summary => string.Join(", ", Items.Select(i => $"{i.Quantity}× {i.Product?.Name}"));
}
public class StatDto { public string Name { get; set; } = ""; public int ProductCount { get; set; } public decimal StockValue { get; set; } public override string ToString() => $"{Name}: {ProductCount} termék, készletérték {StockValue:N0} Ft"; }
public class BasketLine { public ProductDto Product { get; set; } = new(); public int Quantity { get; set; } public string Text => $"{Quantity}× {Product.Name}  –  {Product.Price * Quantity:N0} Ft"; }

// ---- API kliens ----
public static class Api
{
    static readonly HttpClient C = new() { BaseAddress = new Uri("http://localhost:5080/api/") };
    static readonly JsonSerializerOptions J = new(JsonSerializerDefaults.Web);
    public static async Task<T?> Get<T>(string url) => await C.GetFromJsonAsync<T>(url, J);
    public static async Task Send(HttpMethod m, string url, object? body = null)
    {
        var req = new HttpRequestMessage(m, url);
        if (body != null) req.Content = JsonContent.Create(body, mediaType: null, options: J);
        var r = await C.SendAsync(req);
        if (!r.IsSuccessStatusCode) throw new Exception(await r.Content.ReadAsStringAsync());
    }
}

// ---- MVVM alapok ----
public class Obs : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    protected void Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    { if (Equals(field, value)) return; field = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name)); }
}
public class Cmd(Func<Task> run) : ICommand
{
    public event EventHandler? CanExecuteChanged { add { } remove { } }
    public bool CanExecute(object? p) => true;
    public async void Execute(object? p) => await run();
}
public abstract class BaseVM : Obs
{
    string status = ""; public string Status { get => status; set => Set(ref status, value); }
    public abstract Task Load();
    protected Cmd C(Func<Task> f) => new(async () => { try { await f(); } catch (Exception e) { Status = "Hiba: " + e.Message; } });
}
