namespace BoostBay.Wpf;
public partial class ProductsView : System.Windows.Controls.UserControl { public ProductsView() { InitializeComponent(); } }
